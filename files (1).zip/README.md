# Vehicle Sales Institute — PayFast Integration

Complete PayFast payment integration for the VSI course enrollment flow.

---

## Files included

| File | Purpose |
|------|---------|
| `lib/payfast.js` | Signature builder + ITN verifier |
| `lib/students.js` | Supabase account creation + welcome email |
| `pages/api/checkout.js` | POST endpoint — generates signed PayFast payload |
| `pages/api/itn.js` | PayFast ITN callback — handles payment confirmation |
| `.env.example` | All required environment variables |

---

## Setup in 5 steps

### 1. Install dependencies
```bash
npm install @supabase/supabase-js nodemailer
```

### 2. Create a PayFast merchant account
- Go to [payfast.co.za](https://payfast.co.za) → Register as merchant
- Under **Settings → Passphrase**, set a passphrase (required for signature security)
- Under **Settings → ITN**, set your notify URL to `https://yourdomain.co.za/api/itn`
- Copy your **Merchant ID** and **Merchant Key** to `.env.local`

### 3. Create a Supabase project
- Go to [supabase.com](https://supabase.com) → New project (free tier)
- Run the SQL schema from the comment block in `lib/students.js` in the SQL Editor
- Copy your **Project URL** and **Service Role Key** to `.env.local`

### 4. Set up email (SMTP)
Recommended options for South Africa:
- **Mailgun** — reliable, free for 5,000 emails/month
- **SendGrid** — good free tier
- **Zoho Mail** — South African business email

### 5. Configure environment variables
```bash
cp .env.example .env.local
# Edit .env.local with your real values
```

---

## How the payment flow works

```
Student fills in form
        ↓
POST /api/checkout  (server signs payload with passphrase)
        ↓
Browser POSTs to payfast.co.za (hidden form redirect)
        ↓
Student pays on PayFast's secure page
        ↓
PayFast POSTs to /api/itn  (ITN callback)
        ↓
Server verifies signature + confirms with PayFast
        ↓
If COMPLETE → create Supabase account + send welcome email
        ↓
PayFast redirects student to /thanks
```

---

## Testing

PayFast sandbox test credentials (already set in `.env.example`):
- Merchant ID: `10000100`
- Merchant Key: `46f0cd694581a`
- Sandbox URL: `https://sandbox.payfast.co.za/eng/process`

Test card number: `4000 0000 0000 0002`

**To test the ITN locally**, use [ngrok](https://ngrok.com):
```bash
ngrok http 3000
# Use the https ngrok URL as NEXT_PUBLIC_BASE_URL in .env.local
```

---

## Going live checklist

- [ ] Set `PF_SANDBOX=false` in `.env.local`
- [ ] Update `PF_MERCHANT_ID` and `PF_MERCHANT_KEY` to live credentials
- [ ] Update `NEXT_PUBLIC_BASE_URL` to your production domain
- [ ] Set ITN URL in PayFast dashboard to `https://yourdomain.co.za/api/itn`
- [ ] Test one real payment end-to-end before announcing
- [ ] Set up payment notification emails in PayFast dashboard
