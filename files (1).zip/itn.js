/**
 * pages/api/itn.js
 * Vehicle Sales Institute — PayFast ITN (Instant Transaction Notification) handler
 *
 * PayFast POSTs to this URL after every payment attempt.
 * This endpoint MUST return 200 OK or PayFast will retry.
 *
 * Flow:
 *   1. Verify ITN signature + confirm with PayFast
 *   2. If COMPLETE → create student account + send welcome email
 *   3. If CANCELLED / FAILED → log it (no account created)
 *   4. Return 200 OK regardless (errors logged internally)
 *
 * IMPORTANT: Disable Next.js body parsing so we get the raw POST body.
 */

import { verifyITN } from '../../lib/payfast'
import { createStudentAccount, sendWelcomeEmail } from '../../lib/students'

export const config = {
  api: { bodyParser: { type: 'application/x-www-form-urlencoded' } },
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).end()
  }

  const body = req.body

  try {
    // ── 1. Verify the ITN is genuinely from PayFast ─────────────────────────
    await verifyITN(body)

    // ── 2. Handle payment status ────────────────────────────────────────────
    const status = body.payment_status

    if (status === 'COMPLETE') {
      const studentData = {
        email:     body.email_address,
        firstName: body.name_first,
        lastName:  body.name_last,
        pfPaymentId:     body.pf_payment_id,
        amountGross:     body.amount_gross,
        paidAt:          new Date().toISOString(),
        courseAccess:    ['vehicle-sales-mastery'],
      }

      // Create account (idempotent — safe to call twice for same pf_payment_id)
      const student = await createStudentAccount(studentData)

      // Send login credentials email
      await sendWelcomeEmail({
        email:     student.email,
        firstName: student.firstName,
        loginUrl:  `${process.env.NEXT_PUBLIC_BASE_URL}/login`,
        tempPassword: student.tempPassword,
      })

      console.log(`[ITN] Payment COMPLETE for ${body.email_address} — student created`)

    } else if (status === 'CANCELLED') {
      console.log(`[ITN] Payment CANCELLED for ${body.email_address}`)

    } else if (status === 'FAILED') {
      console.log(`[ITN] Payment FAILED for ${body.email_address}`)

    } else {
      console.log(`[ITN] Unknown status: ${status}`)
    }

  } catch (err) {
    // Log the error but ALWAYS return 200 to stop PayFast retrying
    console.error('[ITN] Verification/processing error:', err.message)
  }

  // PayFast requires a 200 OK — anything else triggers a retry
  return res.status(200).end()
}
