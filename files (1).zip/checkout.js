/**
 * pages/api/checkout.js
 * Vehicle Sales Institute — Checkout endpoint
 *
 * POST /api/checkout
 * Body: { firstName, lastName, email, phone, paymentMethod }
 * Returns: { payfastUrl, payload }
 *
 * The browser then POSTs the payload to payfastUrl (via a hidden form).
 * Signature is generated server-side so the passphrase never leaves the server.
 */

import { buildPayfastPayload, PF_CONFIG } from '../../lib/payfast'

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const { firstName, lastName, email, phone, paymentMethod } = req.body

  // Basic validation
  if (!firstName || !lastName || !email) {
    return res.status(400).json({ error: 'firstName, lastName, and email are required' })
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Invalid email address' })
  }

  try {
    const payload = buildPayfastPayload({ firstName, lastName, email, phone, paymentMethod })

    return res.status(200).json({
      payfastUrl: PF_CONFIG.payfastUrl,
      payload,
    })
  } catch (err) {
    console.error('Checkout error:', err)
    return res.status(500).json({ error: 'Failed to build payment payload' })
  }
}
