/**
 * lib/students.js
 * Vehicle Sales Institute — Student account management
 *
 * Uses Supabase for auth + database.
 * Install: npm install @supabase/supabase-js nodemailer
 *
 * Supabase setup:
 *   1. Create project at supabase.com (free tier is fine to start)
 *   2. Run the SQL schema below in the Supabase SQL editor
 *   3. Add SUPABASE_URL and SUPABASE_SERVICE_KEY to .env.local
 *
 * ─── SQL Schema (run in Supabase SQL editor) ────────────────────────────────
 *
 *   create table students (
 *     id              uuid primary key default gen_random_uuid(),
 *     email           text unique not null,
 *     first_name      text not null,
 *     last_name       text not null,
 *     pf_payment_id   text unique,
 *     amount_paid     numeric(10,2),
 *     course_access   text[] default array['vehicle-sales-mastery'],
 *     paid_at         timestamptz,
 *     created_at      timestamptz default now(),
 *     progress        jsonb default '{}'::jsonb
 *   );
 *
 *   -- Enable Row Level Security
 *   alter table students enable row level security;
 *
 *   -- Students can only read their own row
 *   create policy "Students read own record"
 *     on students for select
 *     using (auth.uid()::text = id::text);
 *
 * ────────────────────────────────────────────────────────────────────────────
 */

import { createClient } from '@supabase/supabase-js'
import crypto from 'crypto'
import nodemailer from 'nodemailer'

// Supabase admin client (service key bypasses RLS — server-side only)
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

// ─── Create student account ────────────────────────────────────────────────────

export async function createStudentAccount({ email, firstName, lastName, pfPaymentId, amountGross, paidAt, courseAccess }) {

  // Idempotency check — don't double-create for same PayFast payment
  const { data: existing } = await supabase
    .from('students')
    .select('id, email')
    .eq('pf_payment_id', pfPaymentId)
    .single()

  if (existing) {
    console.log(`[Students] Account already exists for payment ${pfPaymentId}`)
    return { email: existing.email, firstName, tempPassword: null }
  }

  // Generate a secure temporary password
  const tempPassword = crypto.randomBytes(8).toString('base64url').slice(0, 12)

  // Create Supabase Auth user
  const { data: authUser, error: authErr } = await supabase.auth.admin.createUser({
    email,
    password:      tempPassword,
    email_confirm: true,  // mark as confirmed — they proved email via PayFast
  })
  if (authErr) throw new Error(`Auth create failed: ${authErr.message}`)

  // Insert student record
  const { error: dbErr } = await supabase.from('students').insert({
    id:            authUser.user.id,
    email,
    first_name:    firstName,
    last_name:     lastName,
    pf_payment_id: pfPaymentId,
    amount_paid:   parseFloat(amountGross),
    course_access: courseAccess,
    paid_at:       paidAt,
  })
  if (dbErr) throw new Error(`DB insert failed: ${dbErr.message}`)

  console.log(`[Students] Created account for ${email}`)
  return { email, firstName, tempPassword }
}

// ─── Send welcome email ────────────────────────────────────────────────────────

export async function sendWelcomeEmail({ email, firstName, loginUrl, tempPassword }) {
  const transporter = nodemailer.createTransport({
    host:   process.env.SMTP_HOST,
    port:   parseInt(process.env.SMTP_PORT || '587'),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  })

  const html = `
    <!DOCTYPE html>
    <html>
    <body style="font-family: 'Segoe UI', sans-serif; background: #F7F8FA; margin: 0; padding: 32px 16px;">
      <div style="max-width: 520px; margin: 0 auto; background: white; border-radius: 14px; overflow: hidden; border: 1px solid #E2E6EA;">
        
        <div style="background: #0B1F3A; padding: 28px 32px; text-align: center;">
          <div style="color: #C9A84C; font-size: 12px; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 6px;">Vehicle Sales Institute</div>
          <div style="color: white; font-size: 20px; font-weight: 700;">Welcome to the course!</div>
        </div>

        <div style="padding: 32px;">
          <p style="color: #2C2C2C; font-size: 15px; margin-bottom: 16px;">Hi ${firstName},</p>
          <p style="color: #6B7280; font-size: 14px; line-height: 1.7; margin-bottom: 24px;">
            Thank you for enrolling in the <strong style="color: #0B1F3A;">Vehicle Sales Mastery Course</strong>. 
            Your payment is confirmed and your student account is ready.
          </p>

          <div style="background: #F7F8FA; border: 1px solid #E2E6EA; border-radius: 10px; padding: 20px; margin-bottom: 24px;">
            <div style="font-size: 12px; font-weight: 700; color: #0B1F3A; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;">Your login details</div>
            <div style="font-size: 14px; margin-bottom: 8px;"><span style="color: #6B7280;">Email:</span> <strong>${email}</strong></div>
            <div style="font-size: 14px;"><span style="color: #6B7280;">Temporary password:</span> <strong style="font-family: monospace; background: #fff; border: 1px solid #E2E6EA; padding: 2px 8px; border-radius: 4px;">${tempPassword}</strong></div>
          </div>

          <p style="color: #6B7280; font-size: 13px; margin-bottom: 20px;">
            Please change your password after first login. Your access never expires — this is a once-off purchase with lifetime access.
          </p>

          <a href="${loginUrl}" style="display: block; background: #C9A84C; color: #0B1F3A; text-align: center; padding: 14px; border-radius: 8px; font-weight: 700; font-size: 15px; text-decoration: none;">
            Start Learning Now →
          </a>
        </div>

        <div style="background: #F7F8FA; padding: 20px 32px; text-align: center; border-top: 1px solid #E2E6EA;">
          <p style="font-size: 12px; color: #9CA3AF; margin: 0;">
            Questions? Reply to this email or contact info@vehiclesalesinstitute.co.za
          </p>
        </div>
      </div>
    </body>
    </html>
  `

  await transporter.sendMail({
    from:    `"Vehicle Sales Institute" <${process.env.SMTP_USER}>`,
    to:      email,
    subject: 'Your course access — Vehicle Sales Mastery',
    html,
  })

  console.log(`[Email] Welcome email sent to ${email}`)
}
