/**
 * lib/payfast.js
 * Vehicle Sales Institute — PayFast integration helpers
 *
 * SETUP:
 *   1. Create a PayFast merchant account at payfast.co.za
 *   2. Add environment variables (see .env.example)
 *   3. Set PF_SANDBOX=false when going live
 */

const crypto = require('crypto')

// ─── Config ───────────────────────────────────────────────────────────────────

const isSandbox = process.env.PF_SANDBOX === 'true'

export const PF_CONFIG = {
  merchantId:  process.env.PF_MERCHANT_ID,
  merchantKey: process.env.PF_MERCHANT_KEY,
  passphrase:  process.env.PF_PASSPHRASE,
  baseUrl:     process.env.NEXT_PUBLIC_BASE_URL || 'https://vsi.co.za',
  payfastUrl:  isSandbox
    ? 'https://sandbox.payfast.co.za/eng/process'
    : 'https://www.payfast.co.za/eng/process',
}

// ─── Signature builder ─────────────────────────────────────────────────────────

/**
 * Builds the query string PayFast uses for MD5 signing.
 * Order of keys matters — must match PayFast's expected order.
 */
export function buildSignatureString(params, passphrase) {
  const ordered = Object.keys(params)
    .filter(k => params[k] !== '' && params[k] !== null && params[k] !== undefined)
    .map(k => `${k}=${encodeURIComponent(String(params[k])).replace(/%20/g, '+')}`)
    .join('&')

  const withPass = passphrase
    ? `${ordered}&passphrase=${encodeURIComponent(passphrase).replace(/%20/g, '+')}`
    : ordered

  return withPass
}

export function generateSignature(params, passphrase) {
  const str = buildSignatureString(params, passphrase)
  return crypto.createHash('md5').update(str).digest('hex')
}

// ─── Payload builder ───────────────────────────────────────────────────────────

/**
 * Builds the complete PayFast POST payload for the VSI course purchase.
 * Call this server-side (e.g. in a Next.js API route) so the passphrase
 * never reaches the browser.
 */
export function buildPayfastPayload({ firstName, lastName, email, phone, paymentMethod }) {
  const params = {
    // Merchant
    merchant_id:  PF_CONFIG.merchantId,
    merchant_key: PF_CONFIG.merchantKey,

    // URLs
    return_url:  `${PF_CONFIG.baseUrl}/thanks`,
    cancel_url:  `${PF_CONFIG.baseUrl}/enroll`,
    notify_url:  `${PF_CONFIG.baseUrl}/api/itn`,

    // Student
    name_first:    firstName,
    name_last:     lastName,
    email_address: email,
    cell_number:   phone || '',

    // Order
    amount:           '3999.00',
    item_name:        'Vehicle Sales Mastery Course',
    item_description: 'Complete online vehicle sales training — lifetime access',

    // Payment method hint (PayFast will still show all options)
    payment_method: paymentMethod || 'cc',

    // Email confirmation
    email_confirmation:   '1',
    confirmation_address: email,
  }

  // Add signature
  params.signature = generateSignature(params, PF_CONFIG.passphrase)

  return params
}

// ─── ITN verification ──────────────────────────────────────────────────────────

/**
 * Verifies an incoming ITN (Instant Transaction Notification) from PayFast.
 * Must be called server-side only.
 *
 * Steps per PayFast docs:
 *   1. Verify MD5 signature
 *   2. Confirm with PayFast anti-replay endpoint
 *   3. Check amount matches expected value
 *   4. Check merchant_id matches your account
 */
export async function verifyITN(body) {
  const { signature, ...dataWithoutSig } = body

  // Step 1 — verify signature
  const computedSig = generateSignature(dataWithoutSig, PF_CONFIG.passphrase)
  if (computedSig !== signature) {
    throw new Error('ITN signature mismatch')
  }

  // Step 2 — confirm with PayFast (anti-replay)
  const confirmUrl = isSandbox
    ? 'https://sandbox.payfast.co.za/eng/query/validate'
    : 'https://www.payfast.co.za/eng/query/validate'

  const confirmBody = buildSignatureString(dataWithoutSig, null)
  const confirmRes = await fetch(confirmUrl, {
    method:  'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body:    confirmBody,
  })
  const confirmText = await confirmRes.text()
  if (confirmText !== 'VALID') {
    throw new Error(`PayFast confirmation failed: ${confirmText}`)
  }

  // Step 3 — verify amount
  if (parseFloat(body.amount_gross) !== 3999.00) {
    throw new Error(`Amount mismatch: ${body.amount_gross}`)
  }

  // Step 4 — verify merchant
  if (body.merchant_id !== PF_CONFIG.merchantId) {
    throw new Error('Merchant ID mismatch')
  }

  return true
}
